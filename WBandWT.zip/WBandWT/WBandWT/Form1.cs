﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WBandWT
{
    public partial class Form1 : Form
    {
        int fetchRate, issueRMax, instructionBS, latency, nPen, blockSizeICache, sizeICache,
            blockSizeDCache, sizeDCache, strategy, oneCycle;
        private string sSourceFileName = "";
        trace[] traces;
        results result = new results();

        bool[] dirty;
        int[] cacheMemory;
        int[] mainMemory;


        public struct trace
        {
            public string traceType;
            public int currentAdress;
            public int jumpAdress;
        }

        public struct results
        {
            public int store;
            public int load;
            public int branch;
            public int dataCacheAccesses;
            public int total;
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void buttonChooseFile_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                sSourceFileName = openFileDialog.FileName;
            }
        }

        private void buttonStartSimulation_Click(object sender, EventArgs e)
        {
            StreamReader sr = new StreamReader(sSourceFileName);
            List<string> listOfLines = new List<string>();

            string line;
            while ((line = sr.ReadLine()) != null)
            {
                listOfLines.Add(line);
            }

            traces = new trace[listOfLines.Count*5];
            int traceCounter = 0;

            foreach (string lines in listOfLines)
            {
                string[] linesVector = lines.Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);

                for (int i = 0; i < linesVector.Length; i = i + 3)
                {
                    traces[traceCounter].traceType = linesVector[i];
                    traces[traceCounter].currentAdress = Convert.ToInt32(linesVector[i + 1]);
                    traces[traceCounter].jumpAdress = Convert.ToInt32(linesVector[i + 2]);
                    traceCounter++;
                }
            }

            OneCycleCalculations();
            textBoxOneCycle.Text = oneCycle.ToString();

            result.total = result.load + oneCycle + result.branch + result.store;
            textBoxLoad.Text = result.load.ToString();
            textBoxStore.Text = result.store.ToString();
            textBoxBranch.Text = result.branch.ToString();
            textBoxTotal.Text = result.total.ToString();
            textBoxDCAccesses.Text = result.dataCacheAccesses.ToString();

            if (comboBoxStrategy.Text == "Write Back")
            {
                WriteBack();
            }
            else
            {
                WriteThrough();
            }
        }

        public void OneCycleCalculations()
        {
            int numberOneCycle = 0;
            int pc = 0;
            bool firstRead = true;
            bool branchFlag = true;
            int ct = 0;

            foreach (trace trc in traces)
            {
                ct++;
                if (trc.traceType == "S")
                {
                    result.store++;
                    result.dataCacheAccesses++;
                }
                else if (trc.traceType == "L")
                {
                    result.load++;
                    result.dataCacheAccesses++;
                }
                else
                {
                    result.branch++;
                }

                if (firstRead)
                {
                    numberOneCycle += trc.currentAdress - pc;
                    firstRead = false;
                }
                else
                {
                    if ((trc.currentAdress != pc) && (branchFlag == true))
                    {
                        numberOneCycle += trc.currentAdress - pc;
                    }
                    else if (branchFlag == true)
                    {
                        numberOneCycle += trc.currentAdress - pc;
                    }
                    else
                    {
                        numberOneCycle += trc.currentAdress - pc - 1;
                    }
                }

                if (trc.traceType == "B")
                {
                    pc = trc.jumpAdress;
                    branchFlag = true;
                }
                else
                {
                    pc = trc.currentAdress;
                    branchFlag = false;
                }
            }

            oneCycle = numberOneCycle;
        }

        private void comboBoxFetchRate_SelectedIndexChanged(object sender, EventArgs e)
        {
            fetchRate = Int32.Parse(comboBoxFetchRate.SelectedItem.ToString());
        }

        private void comboBoxIRMax_SelectedIndexChanged(object sender, EventArgs e)
        {
            issueRMax = Int32.Parse(comboBoxIRMax.SelectedItem.ToString());
        }

        private void comboBoxIBS_SelectedIndexChanged(object sender, EventArgs e)
        {
            instructionBS = Int32.Parse(comboBoxIBS.SelectedItem.ToString());
        }

        private void numericUpDownLatency_ValueChanged(object sender, EventArgs e)
        {
            latency = (int)numericUpDownLatency.Value;
        }

        private void comboBoxNPen_SelectedIndexChanged(object sender, EventArgs e)
        {
            nPen = Int32.Parse(comboBoxNPen.SelectedItem.ToString());
        }

        private void comboBoxICblockSize_SelectedIndexChanged(object sender, EventArgs e)
        {
            blockSizeICache = Int32.Parse(comboBoxICblockSize.SelectedItem.ToString());
        }

        private void comboBoxSizeIC_SelectedIndexChanged(object sender, EventArgs e)
        {
            sizeICache = Int32.Parse(comboBoxSizeIC.SelectedItem.ToString());
        }

        private void comboBoxDCblockSize_SelectedIndexChanged(object sender, EventArgs e)
        {
            blockSizeDCache = Int32.Parse(comboBoxDCblockSize.SelectedItem.ToString());
        }

        private void comboBoxDCSize_SelectedIndexChanged(object sender, EventArgs e)
        {
            sizeDCache = Int32.Parse(comboBoxDCSize.SelectedItem.ToString());
            dirty = new bool[sizeDCache];
            cacheMemory = new int[sizeDCache];
            mainMemory = new int[sizeDCache * 100];
        }

        private void comboBoxStrategy_SelectedIndexChanged(object sender, EventArgs e)
        {
            strategy = Int32.Parse(comboBoxStrategy.SelectedItem.ToString());
        }

        public void WriteBack()
        {

        }

        
        public void WriteThrough()
        {
            Queue<trace> instructionBufferSizeMemory = new Queue<trace>();
            int instructionBufferSizeFilled = 0;

            for (int i = 0; i < traces.Count(); i++)
            {
                // Daca bufferul de instructiuni nu este plin putem adauga FR instructiunii in continuare in el
                if (instructionBufferSizeFilled < instructionBS)
                {
                    for (int j = 0; j < fetchRate; j++)
                    {
                        instructionBufferSizeMemory.Enqueue(traces[i]);
                        i++;
                    }
                }
            }
        }
    }
}
